# class RestAPITest
#
#
#   get_response = RestClient.get( "https://applicationname-api-sbox02.herokuapp.com/api/v1/users",
#                                {
#                                    "Content-Type" => "text/html",
#                                    "Authorization" => "token 4d012314b7e46008f215cdb7d120cdd7",
#                                    "Manufacturer-Token" => "8d0693ccfe65104600e2555d5af34213"
#                                }
# )
#
#
# end