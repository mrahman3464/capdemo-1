# Given(/^User navigate to salesforce Login Page$/) do
#   visit SalesForceLogInPage
# end
#
# Then(/^User logs in with valid credentials$/) do
#   on(SalesForceLogInPage).signIn
# end